package tasks;
import java.util.*;
import service.VersionManagementService;

public class TaskExecuterFactory {
	private Map<String, TaskExecuter> tasks = new HashMap<>();
	
	public TaskExecuterFactory(final VersionManagementService versionManagementService) {
	//	tasks.put("UPLOADVERSION", new UploadVersionExecuter());
	}
}
