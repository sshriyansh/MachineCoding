package tasks;

import service.VersionManagementService;

public class UploadVersionTaskExecuter extends TaskExecuter {
	
	public UploadVersionTaskExecuter(VersionManagementService versionManagementService) {
		super(versionManagementService);
		// TODO Auto-generated constructor stub
	}

	public void execute(String task) {
		
	}

}
