package model.rollout;

public class BetaRolloutStrategy {

}
